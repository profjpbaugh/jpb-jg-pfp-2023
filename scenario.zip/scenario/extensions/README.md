In this directory you can put any .cc file you want to be compiled and linked to your scenarios. 

This mainly useful for custom extension of ndnSIM and NS-3.

