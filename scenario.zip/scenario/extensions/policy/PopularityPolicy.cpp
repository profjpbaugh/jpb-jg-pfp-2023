#include "PopularityPolicy.hpp"

#include <iostream>

PopularityPolicy::PopularityPolicy() : Policy(POLICY_NAME)
{
  std::cout<<"Calling the constructor in PopularityPolicy"<<std::endl;
  popularityManager = nullptr; 
}//end ctor

PopularityPolicy::~PopularityPolicy()
{
  std::cout<<"Calling the destructor in PopularityPolicy"<<std::endl;
}//end dtor

//---------------------set the popularity manager
void
PopularityPolicy::setPopularityManager(std::shared_ptr<PopMan> pm) 
{
  popularityManager = pm;
}//end setPopularityManager

//--------------------do after insert
void
PopularityPolicy::doAfterInsert(nfd::cs::iterator it)
{
  auto dataIt = it->getData();
  std::string dataName = dataIt.getName().toUri();
  popularityManager->addIterator(it);

  std::string strTempName;

  //CS is getting crowded.  Evict the least popular content
  if(getCs()->size() > getLimit()) //need to call replacement routine
  {
    nfd::cs::iterator iteratorToRemove = popularityManager->getContentToEvict();
    strTempName = iteratorToRemove->getData().getName().toUri();

    //std::cout<<"Evicting content: "<<strTempName<<std::endl;
    //std::cout<<"\twith popularity: "<<popularityManager->getOverallPopularity(strTempName);
    //std::cout<<std::endl;
    popularityManager->removeIterator(iteratorToRemove);

    this->emitSignal(beforeEvict, iteratorToRemove);
  }//end if


  
}//end doAfterInsert

//--------------------do after refresh
void
PopularityPolicy::doAfterRefresh(nfd::cs::iterator it)
{

}//end doAfterRefresh

//-------------------do before erase
void
PopularityPolicy::doBeforeErase(nfd::cs::iterator it)
{

}//end doBeforeErase

//------------------do before use
void
PopularityPolicy::doBeforeUse(nfd::cs::iterator it)
{

}//end doBeforeUse

//-----------------evict entries
void
PopularityPolicy::evictEntries()
{

}//end evictEntries


