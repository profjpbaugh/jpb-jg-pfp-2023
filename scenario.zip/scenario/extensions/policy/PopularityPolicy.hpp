#ifndef POPULARITY_POLICY_H
#define POPULARITY_POLICY_H

#include <memory>
#include <string>

#include "ns3/ndnSIM/NFD/daemon/fw/PopMan.hpp"
#include "ns3/ndnSIM/NFD/daemon/table/cs-policy.hpp"
#include "ns3/ndnSIM/ndn-cxx/data.hpp"
#include "ns3/ndnSIM/model/ndn-common.hpp"

const std::string POLICY_NAME = "PopularityPolicy";

class
PopularityPolicy : public nfd::cs::Policy
{
  public:
    PopularityPolicy();
    ~PopularityPolicy();
  
    void
    setPopularityManager(std::shared_ptr<PopMan> pm);
  
  protected:
    void
    doAfterInsert(nfd::cs::iterator it);

    void
    doAfterRefresh(nfd::cs::iterator it);

    void
    doBeforeErase(nfd::cs::iterator it);

    void
    doBeforeUse(nfd::cs::iterator it);

    void
    evictEntries();
    
  private:
    std::shared_ptr<PopMan> popularityManager; 
};
#endif
