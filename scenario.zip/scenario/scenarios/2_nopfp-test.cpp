
// 1/27/2018 
// pfp3:  2_nopfp-test 
// larger attacker scenario, based off of Xie et al. 
// allowing all routers to be content routers
// thus, we need separate forwarder, Cs, Policy, and PopMan objects
// for each router

#include "ns3/ndnSIM/model/ndn-common.hpp"
#include "ns3/ptr.h"
#include "ns3/node.h"

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

//required for Popularity Management and Policy
#include "ns3/ndnSIM/NFD/daemon/fw/PopMan.hpp"
#include "policy/PopularityPolicy.hpp"

//custom consumer stuff?
//#include "ns3/ndnSIM/apps/ndn-consumer-cbr.hpp"


//tracing libraries
#include "ns3/ndnSIM/utils/tracers/ndn-cs-tracer.hpp" 

namespace ns3 {

void
printContents(nfd::Cs& contentStore, shared_ptr<PopMan> popMan);

void
printContentStoreToFile(nfd::Cs* contentStore, shared_ptr<PopMan> popMan,
                        shared_ptr<ofstream> outfile, int iteration);

void
setCSLimitToZero(NodeContainer& nodes, int nodeNum);

void
installConsumers(NodeContainer& nodes, int lowIndex, int highIndex);

void
installConsumersAdvTop(NodeContainer& nodes, int lowIndex, int highIndex);

void
connectConsumers(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex);

void
connectConsumersAdvTop(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex);

//modified for multi router scenario
void
handler(shared_ptr<std::ofstream> outfile, int iteration, nfd::Cs* cs,
        shared_ptr<PopMan> popMan);


int
main(int argc, char* argv[])
{

  const size_t CS_SIZE = 500;
  const int NUM_NODES = 23;   
  const double NUM_SECONDS = 60.0;
  const int NUM_ROUTERS = 5;

  // setting default parameters for PointToPoint links and channels
  Config::SetDefault("ns3::PointToPointNetDevice::DataRate", StringValue("50Mbps"));
  Config::SetDefault("ns3::PointToPointChannel::Delay", StringValue("10ms"));
  Config::SetDefault("ns3::DropTailQueue::MaxPackets", StringValue("20"));

  // Read optional command-line parameters (e.g., enable visualizer with ./waf --run=<> --visualize
  CommandLine cmd;
  cmd.Parse(argc, argv);

  // Creating nodes
  NodeContainer nodes;
  nodes.Create(NUM_NODES);


  //*******************************//
  //****** 5 routers **************//
  std::vector<shared_ptr<ofstream>> outfileVec;
  string contentFileName = "";
  for(int i = 0; i < NUM_ROUTERS; i++) 
  {
    contentFileName = "r";
    contentFileName += std::to_string(i);
    contentFileName +="-NOPFP-cs_content.txt";
  
    outfileVec.push_back(make_shared<ofstream>(contentFileName.c_str()));
  }//end for 

  // Connecting nodes using two links
  //connecting the router(1) to the producer(0)
  PointToPointHelper p2p;
  p2p.Install(nodes.Get(0), nodes.Get(1));  //0 is producer, 1 is router

  //connect the will-be-consumers to the router or intermediate nodes
  connectConsumersAdvTop(p2p, nodes, 2, NUM_NODES-1);


  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes(true);
  ndnHelper.setPolicy("nfd::cs::lru");
  ndnHelper.InstallAll();

  const int numHighestConsumer = NUM_NODES-1;

  std::cout<<"Testing - about the choose forwarding strategy"<<std::endl;
  
  // Choosing forwarding strategy
  ndn::StrategyChoiceHelper::InstallAll("/prefix", "/localhost/nfd/strategy/multicast");

  //added JPB 6/13/17
  ndn::GlobalRoutingHelper grh;
  grh.InstallAll();

  // Installing applications

  std::cout<<"About to install consumers"<<std::endl;
  installConsumersAdvTop(nodes, 2, numHighestConsumer);
  std::cout<<"Consumers installed!"<<std::endl;
 
  
  // Producer
  ndn::AppHelper producerHelper("ns3::ndn::Producer");
  // Producer will reply to all requests starting with /prefix
  producerHelper.SetPrefix("/prefix");
  producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  producerHelper.Install(nodes.Get(0));  

  //added JPB 6/13/17
  Ptr<Node> producer = nodes.Get(0);

  /*
      JPB - 1/26/18 Updated for multi-router scenario (multiple content routers)
      Testing forwarder compilation and method(s)
  */
  //get l3protocol for the ROUTERS
  vector<Ptr<ndn::L3Protocol>> l3protocol(NUM_ROUTERS);
 
  //*********************************************//  
  //******** all routers need protocol **********//
  //*********************************************//
  //
  //         
  ////A --- R1 --- R2 --- R3 --- R4 --- R0 --- (producer)
  //        |      |             |
  //      C1-C12  C2, C13       C3, C14
  //
  //node 0  = producer
  //node 1  = R0 
  //node 2  = A1 (attacker #1) 
  //node 3  = R1 (router #1)
  //node 4  = R2
  //node 5  = R3
  //node 6  = R4
  //node 7  = C1 (consumer #1)
  //node 8  = C2
  //node 9  = C3
  //node 10 = C4
  //node 11 = C5
  //node 12 = C6
  //node 13 = C7
  //node 14 = C8
  //node 15 = C9
  //node 16 = C10
  //node 17 = C11
  //node 18 = C12
  //node 19 = C13
  //node 20 = C14
  //node 21 = A2
  //node 22 = A3

  l3protocol[0] = (nodes.Get(1))->GetObject<ndn::L3Protocol>(); //router 0
  l3protocol[1] = (nodes.Get(3))->GetObject<ndn::L3Protocol>(); //router 1
  l3protocol[2] = (nodes.Get(4))->GetObject<ndn::L3Protocol>(); //router 2
  l3protocol[3] = (nodes.Get(5))->GetObject<ndn::L3Protocol>(); //router 3 
  l3protocol[4] = (nodes.Get(6))->GetObject<ndn::L3Protocol>(); //router 4

  //************************************************************************//  

  //**********************************//
  //******* get forwarders ***********//
  //**********************************//
  //nfd::Forwarder& forwarder[NUM_ROUTERS];
  vector<shared_ptr<nfd::Forwarder>> forwarder(NUM_ROUTERS);

  for(int i = 0; i < NUM_ROUTERS; i++)
  {
    forwarder[i] =l3protocol[i]->getForwarder();
  }//end for (getting the forwarders from the routers

  //************************************************************************//

  //************************************//
  //*********** set limits for *********//
  //*********  Content Stores **********//
  //************************************//

  for(int i = 0; i < NUM_ROUTERS; i++)
  {
    forwarder[i]->getCs().setLimit(CS_SIZE);
  }//end for (getting the content stores and limits set 

  //***********************************************************//
 
  //************************************// 
  //******* create pop managers ********//
  //***** and set for forwarders *******//
  //************************************//
  vector<shared_ptr<PopMan>> popularityManagers(NUM_ROUTERS);

  for(int i = 0; i < NUM_ROUTERS; i++) 
  {
    popularityManagers[i] = make_shared<PopMan>();
    //param at end = false, since usePFP should be false
    forwarder[i]->setPopularityManager(popularityManagers[i], true, false);
    forwarder[i]->setIsStorageRouter(true);
  }//end for (getting the popularity managers for each router 

  //**********************************************************//
  
  //**************************************//
  //******* create policy objects ********//
  //**************************************//
  //DO NOT USE FOR NOPFP 
  /*unique_ptr<PopularityPolicy> policy =
         ndn::make_unique<PopularityPolicy>();
  */

  //vector<unique_ptr<PopularityPolicy>> policies(NUM_ROUTERS);

  /*
    for(int i = 0; i < NUM_ROUTERS; i++)
    {
      //policies[i] = ndn::make_unique<PopularityPolicy>();

     //policies[i]->setLimit(forwarder[i]->getCs().getLimit()); //should be same as Cs::setLimit val
      //policies[i]->setPopularityManager(popularityManagers[i]);
      //forwarder[i]->getCs().setPolicy(move(policies[i]));
  }//end for (setting policies for each of the routers

  */
  setCSLimitToZero(nodes, 2); //attacker = 2 
  //all consumers should have 0 Cs size 
  for(int i = 7; i <= 20; i++) 
  {
    setCSLimitToZero(nodes, i);
  }


  //************************************************************************//
 
  //*************************************************//
  //*********** set popman for forwarders ***********// 
  //*************************************************//
 
  for(int i = 0; i < NUM_ROUTERS; i++) 
  {
    //the popMan, is Storage Router?, use PFP or no? 
    forwarder[i]->setPopularityManager(popularityManagers[i], true, true);
  }//end for (setting pop managers for each forwarder
 
  std::cout<<"In scenario, after forwarder set popularity manager."<<std::endl; 

  
  Simulator::Stop(Seconds(NUM_SECONDS));

  for(int i = 1; i <= NUM_SECONDS; i++)
  {
    //changed 1 to i as argument to Seconds JPB 1/15/2018
    for(int j = 0; j < NUM_ROUTERS; j++)
    {
      Simulator::Schedule(Seconds(i), &handler, outfileVec[j], i,
                                      &forwarder[j]->getCs(), 
                                      popularityManagers[j]);
    }//end for each router...
  }//end for each second...

  Simulator::Run();

  std::cout<<"\n\n\n";
  //std::cout<<"--------------------| Summary from PopMan |---------------------"<<std::endl;
  //popularityManager->printSummaryByFace();

  //******************************************************************************//

  //***********************************************//
  //********* print hit miss per router ***********//
  //***********************************************//

  string strHitMiss = "";
  for(int i = 0; i < NUM_ROUTERS; i++)
  {
    strHitMiss = "r";
    strHitMiss += to_string(i);
    strHitMiss +="-NOPFP-cs-hit-miss.txt";
    forwarder[i]->printCsHitMiss(strHitMiss);
  }//end for (printing the hit/miss for each router 

  Simulator::Destroy();

  for(int i = 0; i < NUM_ROUTERS; i++)
  {
    outfileVec[i]->close();  //close the cs_data file
  } 
  std::cout<<"Scenario has completed..."<<std::endl; 
  return 0;
}


//helper functions 
//print contents of content store
void
printContents(nfd::Cs& contentStore, shared_ptr<PopMan> popMan)
{
  //std::ofstream outfile;
  //outfile.open("cs_contents.txt");

  std::cout<<"--------------| CONTENT STORE |-----------------"<<std::endl;
  std::cout<<"\tSize: "<<contentStore.getLimit()<<std::endl;
  //outfile<<"\tSize: "<<contentStore.getLimit()<<std::endl;

  for(auto it = contentStore.begin();
      it != contentStore.end();
      it++)
  {
    auto dataFromIt = it->getFullName();
    ndn::Name::Component component = it->getName().at(1);

    std::cout<<"Full Name: "<<dataFromIt.toUri()<<std::endl;

    std::string shortName = popMan->getShortName(dataFromIt.toUri(),"/");

    std::cout<<"Content Short Name: "<<shortName<<std::endl;
//    std::cout<<"\tOverall Popularity: "<<popMan->getOverallPopularity(shortName)<<std::endl;
    
  }//end for
}//end printContents

void
printContentStoreToFile(nfd::Cs* contentStore, shared_ptr<PopMan> popMan,
                        shared_ptr<ofstream> outfile, int iteration)
{
  (*outfile)<<"Iteration "<<iteration<<std::endl;
  int count = 0;
  (*outfile)<<"Item Num\tShort Name\tSequence Num"<<std::endl;

  for(auto it = contentStore->begin(); it != contentStore->end(); it++)
  {

    ndn::Name::Component component = it->getName().at(1); //get seq num
    auto dataFromIt = it->getFullName();

    (*outfile)<<count<<", "<<popMan->getShortName(dataFromIt.toUri(), "/")<<", ";
    if(component.isSequenceNumber())
    {
      (*outfile)<<component.toSequenceNumber();
    }//end if

    (*outfile)<<std::endl;
    count++;
  }//end for

  (*outfile)<<std::endl;
}//end printContentStoreToFile 

//set the CS limit to 0
void
setCSLimitToZero(NodeContainer& nodes, int nodeNum) 
{
  Ptr<ndn::L3Protocol> l3node = (nodes.Get(nodeNum))->GetObject<ndn::L3Protocol>();
  nfd::Forwarder& theForwarder = *l3node->getForwarder();
  nfd::Cs& nodeCS = theForwarder.getCs();
  nodeCS.setLimit(0);
}//end setCSLimitToZero


//convenience function created 6/15/2017
void
installConsumers(NodeContainer& nodes, int lowIndex, int highIndex)
{

  const int NUM_ATTACKERS = 6;
  const int NUM_OF_CONTENTS = 10000;

  //ndn::AppHelper consumerHelper("ns3::ndn::ConsumerCbr");
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerZipfMandelbrot");
  ndn::AppHelper attackerHelper("ns3::ndn::ConsumerCbr");

  //1,000,000 content object space (K = 10^6) per Xie et al.
  consumerHelper.SetAttribute("NumberOfContents", UintegerValue(NUM_OF_CONTENTS));
  //the value "s" is the alpha value in the zipf-like distribution
  //i.e., 1/i^alpha  
  consumerHelper.SetAttribute("s", StringValue("0.8"));
 
  consumerHelper.SetPrefix("/prefix");
  attackerHelper.SetPrefix("/prefix");

  //general attributes
  consumerHelper.SetAttribute("Frequency", StringValue("120"));
  //consumerHelper.SetAttribute("UpperBound", UintegerValue(5));

  //install regular nodes - numbers are beyond the 
  //attacker nodes
  for(int i = lowIndex + NUM_ATTACKERS; i <= highIndex; i++) 
  {
    consumerHelper.Install(nodes.Get(i)); 
  }//end for    
      
  //testing attacker at lowIndex
  //with really fast attacker (10 attackers)
  attackerHelper.SetAttribute("Frequency", StringValue("720"));


  attackerHelper.SetAttribute("IsAttacker", UintegerValue(2));  //yes it's an attacker
  for(int i = lowIndex; i <= lowIndex + NUM_ATTACKERS-1; i++) 
  {
    //attackerHelper.Install(nodes.Get(i));
    consumerHelper.Install(nodes.Get(i));  //no attacker scenario
  }
}//end installConsumers

void
installConsumersAdvTop(NodeContainer& nodes, int lowIndex, int highIndex)
{
  const int NUM_OF_CONTENTS = 10000;
  
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerZipfMandelbrot");
  ndn::AppHelper attackerHelper("ns3::ndn::ConsumerCbr");

  consumerHelper.SetAttribute("s", StringValue("0.8"));  //alpha value Zipf-like dist

  consumerHelper.SetAttribute("NumberOfContents", UintegerValue(NUM_OF_CONTENTS));

  consumerHelper.SetPrefix("/prefix");
  attackerHelper.SetPrefix("/prefix");

  //general attributes
  consumerHelper.SetAttribute("Frequency", StringValue("120"));
  attackerHelper.SetAttribute("Frequency", StringValue("720"));

  attackerHelper.SetAttribute("IsAttacker", UintegerValue(2));  //yes it's an attacker!

  //install in attacker(s) and consumers
  //attackers:
    attackerHelper.Install(nodes.Get(lowIndex)); 
    attackerHelper.Install(nodes.Get(lowIndex+19));
    attackerHelper.Install(nodes.Get(lowIndex+20));

  //consumers:
  for(int i = 5; i <= 18; i++)
  {
    consumerHelper.Install(nodes.Get(lowIndex + i));
  }
}//end installConsumersAdvTop


//Added convenience function - 6/15/2017
//create actual connection from consumer nodes to the router
void
connectConsumers(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex)
{
  
  for(int i = lowIndex; i <= highIndex; i++)
  {
    p2p.Install(nodes.Get(i), nodes.Get(1));  //direct to router
  }//end for  
  
}//end connectConsumers


//more advanced toplogy - 1/26/2018
void
connectConsumersAdvTop(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex)
{
  //5 routers, 14 regular consumers, 1 attacker
  //A is the lowIndex user
  //A1-A3 --- R1 ------ R2 --- R3 --- R4 --- (content router) --- (producer)
  //          |         |             |
  //      C1,C4-C12    C2, C13      C3, C14
  //

  //install attackers
  p2p.Install(nodes.Get(lowIndex), nodes.Get(lowIndex+1));    //A1 -- R1
  p2p.Install(nodes.Get(lowIndex+19), nodes.Get(lowIndex+1)); //A2 -- R1
  p2p.Install(nodes.Get(lowIndex+20), nodes.Get(lowIndex+1)); //A3 -- R1
 
  p2p.Install(nodes.Get(lowIndex+1), nodes.Get(lowIndex+2)); //R1 -- R2
  p2p.Install(nodes.Get(lowIndex+2), nodes.Get(lowIndex+3)); //R2 -- R3
  p2p.Install(nodes.Get(lowIndex+3), nodes.Get(lowIndex+4)); //R3 -- R4
  p2p.Install(nodes.Get(lowIndex+4), nodes.Get(1));          //R4 -- R0 

  p2p.Install(nodes.Get(lowIndex+1), nodes.Get(lowIndex+5));  //R1 -- C1
  p2p.Install(nodes.Get(lowIndex+2), nodes.Get(lowIndex+6));  //R2 -- C2
  p2p.Install(nodes.Get(lowIndex+2), nodes.Get(lowIndex+17)); //R2 -- C13
  p2p.Install(nodes.Get(lowIndex+4), nodes.Get(lowIndex+7));  //R4 -- C3
  p2p.Install(nodes.Get(lowIndex+4), nodes.Get(lowIndex+18)); //R4 -- C14

  //install consumers
  for(int i = 8; i <= 16; i++)
  {
    p2p.Install(nodes.Get(lowIndex+1), nodes.Get(lowIndex+i));
  }
  

}//end connectConsumerAdvTop
  
//the handler for data recording
void
handler(shared_ptr<ofstream> outfile, int iteration,
        nfd::Cs* cs, shared_ptr<PopMan> popMan ) 
{
  printContentStoreToFile(cs, popMan, outfile, iteration );
  //(*outfile)<<"Testing iteration "<<iteration<<std::endl;     
}//end handler

} // namespace ns3

int
main(int argc, char* argv[])
{
  return ns3::main(argc, argv);
}
