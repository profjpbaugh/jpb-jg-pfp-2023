If you do not want (temporarily) some scenario to be automatically compiled, place it in this folder and it will be ignored during build phase.

