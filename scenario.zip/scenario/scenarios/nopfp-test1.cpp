
// 12/7/2017 
// nopfp-test1
// testing the PFP v NOPFP scenario with additional attack
// scenarios (largely based on Xie et al. 

#include "ns3/ndnSIM/model/ndn-common.hpp"
#include "ns3/ptr.h"
#include "ns3/node.h"

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <iostream>
#include <fstream>
#include <string>

//required for Popularity Management and Policy
#include "ns3/ndnSIM/NFD/daemon/fw/PopMan.hpp"
#include "policy/PopularityPolicy.hpp"

//custom consumer stuff?
//#include "ns3/ndnSIM/apps/ndn-consumer-cbr.hpp"


//tracing libraries
#include "ns3/ndnSIM/utils/tracers/ndn-cs-tracer.hpp" 

namespace ns3 {

//JPB added 6/6/17
//prototypes
void
printContents(nfd::Cs& contentStore, shared_ptr<PopMan> popMan);

//JPB added 10/20/17
//print the content of the content store to file for analysis
void
printContentStoreToFile(nfd::Cs* contentStore, shared_ptr<PopMan> popMan,
                        ofstream* outfile, int iteration);

void
setCSLimitToZero(NodeContainer& nodes, int nodeNum);

void
installConsumers(NodeContainer& nodes, int lowIndex, int highIndex);

void
connectConsumers(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex);

void
handler(std::ofstream* outfile, int iteration, nfd::Cs* cs, shared_ptr<PopMan> popMan);

int
main(int argc, char* argv[])
{

  const size_t CS_SIZE = 100;
  const int NUM_NODES = 20;
  const double NUM_SECONDS = 120.0;

  // setting default parameters for PointToPoint links and channels
  Config::SetDefault("ns3::PointToPointNetDevice::DataRate", StringValue("10Mbps"));
  Config::SetDefault("ns3::PointToPointChannel::Delay", StringValue("10ms"));
  Config::SetDefault("ns3::DropTailQueue::MaxPackets", StringValue("20"));

  // Read optional command-line parameters (e.g., enable visualizer with ./waf --run=<> --visualize
  CommandLine cmd;
  cmd.Parse(argc, argv);

  // Creating nodes
  NodeContainer nodes;
  nodes.Create(NUM_NODES);

  //creating outfile for handler / cs info
  std::ofstream outfile;
  outfile.open("NOPOP-cs_content.txt");

  // Connecting nodes using two links
  //connecting the router(1) to the producer(0)
  PointToPointHelper p2p;
  p2p.Install(nodes.Get(0), nodes.Get(1));  //0 is producer, 1 is router

  //connect the will-be-consumers to the router or intermediate nodes
  connectConsumers(p2p, nodes, 2, NUM_NODES-1);  


  //install from intermediate, non-storing routers
  //to the storage router
  //   p2p.Install(nodes.Get(12), nodes.Get(1));  //install from I1 to Router
  //   p2p.Install(nodes.Get(13), nodes.Get(1));  //install from I2 to Router
  //   p2p.Install(nodes.Get(14), nodes.Get(1));  //install from I3 to router

  // Install NDN stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes(true);
  ndnHelper.setPolicy("nfd::cs::lru");  //for non-popularity policy
  ndnHelper.InstallAll();


  std::cout<<"Testing - about the choose forwarding strategy"<<std::endl;
  
  // Choosing forwarding strategy
  ndn::StrategyChoiceHelper::InstallAll("/prefix", "/localhost/nfd/strategy/multicast");

  //added JPB 6/13/17
  ndn::GlobalRoutingHelper grh;
  grh.InstallAll();

  const int numHighestConsumer = NUM_NODES-1;
  // Installing applications

  installConsumers(nodes, 2, numHighestConsumer);
  
  // Producer
  ndn::AppHelper producerHelper("ns3::ndn::Producer");
  // Producer will reply to all requests starting with /prefix
  producerHelper.SetPrefix("/prefix");
  producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  producerHelper.Install(nodes.Get(0));  

  //added JPB 6/13/17
  Ptr<Node> producer = nodes.Get(0);

  //added JPB 7/29/17	
  Ptr<Node> routerNode = nodes.Get(1);  //the router node is required
                                        //for CsTracer

 
  //grh.AddOrigins("/prefix", producer);
  //ndn::GlobalRoutingHelper::CalculateRoutes();

  /*
      JPB - Added 5/18/2017
      Testing forwarder compilation and method(s)
  */
  //get l3protocol for the ROUTER
  Ptr<ndn::L3Protocol> l3protocol = (nodes.Get(1))->GetObject<ndn::L3Protocol>();


  //get forwarder for the ROUTER (node 1) 
  nfd::Forwarder& forwarder = *l3protocol->getForwarder();

  //get cs (content store) for the ROUTER (node 1)
  nfd::Cs& myContentStore = forwarder.getCs();
  myContentStore.setLimit(CS_SIZE);  //set the limit of items in the content store
  
  
   //create popularity manager
   //even without applying popularity manager 
   //we can use it for some useful functions such
   //as getting short name to print to file (of contents)
  shared_ptr<PopMan> popularityManager = make_shared<PopMan>();

  //create and set Policy
  //for the content store
  //unique_ptr<PopularityPolicy> policy =
  //       ndn::make_unique<PopularityPolicy>();

  //policy->setLimit(myContentStore.getLimit()); //should be same as Cs::setLimit val
 
  //do not utilize popularity manager 
  //policy->setPopularityManager(popularityManager);

  //myContentStore.setPolicy("nfd::cs::lru");  //default LRU policy
  
  //JPB test 6/14/2017
  //set CS for a consumer nodes
  //so accurate information can be gathered
  for(int i = 2; i <= numHighestConsumer; i++) 
  {
    setCSLimitToZero(nodes, i);
  }
 

  //we are a storage router (true)
  //but shouldn't use popularity manager - so usePFP is false 
  forwarder.setPopularityManager(popularityManager, true, false);
  forwarder.setIsStorageRouter(true);  //keep pop manager nullptr, but indicate
                                       //this is a storage router 

  
  Simulator::Stop(Seconds(NUM_SECONDS));
  //Simulator::Stop(Seconds(60.0));

  
// ndn::CsTracer::Install(routerNode, "cs-hit-miss.txt", Seconds(1));
//  ndn::CsTracer::InstallAll("cs-hit-miss.txt", Seconds(1));

  for(int i = 1; i <= NUM_SECONDS; i++)
  {
    //change to i from 1 JPB 1/15/2018
    Simulator::Schedule(Seconds(i), &handler, &outfile, i,
                                    &myContentStore, popularityManager);
  }
  //Simulator::Schedule(Seconds(1), &handler, &outfile);

  Simulator::Run();

  std::cout<<"About to print the contents of the CS"<<std::endl;
  printContents(myContentStore, popularityManager);

  std::cout<<"\n\n\n";
  std::cout<<"--------------------| Summary from PopMan |---------------------"<<std::endl;
  //popularityManager->printSummary();
  //popularityManager->printSummaryByFace();

  forwarder.printCsHitMiss("NOPOP-cs-hit-miss.txt");
 
  Simulator::Destroy();

  outfile.close();  //close the cs_data file
  std::cout<<"Scenario is completed..."<<std::endl; 
  return 0;
}


//helper functions 
//print contents of content store
void
printContents(nfd::Cs& contentStore, shared_ptr<PopMan> popMan)
{
  //std::ofstream outfile;
  //outfile.open("cs_contents.txt");

  std::cout<<"--------------| CONTENT STORE |-----------------"<<std::endl;
  std::cout<<"\tSize: "<<contentStore.getLimit()<<std::endl;
  //outfile<<"\tSize: "<<contentStore.getLimit()<<std::endl;

  for(auto it = contentStore.begin();
      it != contentStore.end();
      it++)
  {
    auto dataFromIt = it->getFullName();
    std::cout<<"Full Name: "<<dataFromIt.toUri()<<std::endl;

    std::string shortName = popMan->getShortName(dataFromIt.toUri(),"/");

    std::cout<<"Content Short Name: "<<shortName<<std::endl;
//    std::cout<<"\tOverall Popularity: "<<popMan->getOverallPopularity(shortName)<<std::endl;
    
  }//end for
}//end printContents

void
printContentStoreToFile(nfd::Cs* contentStore, shared_ptr<PopMan> popMan,
                        ofstream* outfile, int iteration)
{
  (*outfile)<<"Iteration "<<iteration<<std::endl;
  int count = 0;
  (*outfile)<<"Item Num\tShort Name\tSequence Num"<<std::endl;

  for(auto it = contentStore->begin(); it != contentStore->end(); it++)
  {
    ndn::Name::Component component = it->getName().at(1);  //get seq num
    auto dataFromIt = it->getFullName();

    (*outfile)<<count<<", "<<popMan->getShortName(dataFromIt.toUri(), "/")<<", ";
    if(component.isSequenceNumber()) 
    {
      (*outfile)<<component.toSequenceNumber();
    }
  
    (*outfile)<<std::endl;
    count++;
  }//end for

  (*outfile)<<std::endl;
}//end printContentStoreToFile 

//set the CS limit to 0
void
setCSLimitToZero(NodeContainer& nodes, int nodeNum) 
{
  Ptr<ndn::L3Protocol> l3node = (nodes.Get(nodeNum))->GetObject<ndn::L3Protocol>();
  nfd::Forwarder& theForwarder = *l3node->getForwarder();
  nfd::Cs& nodeCS = theForwarder.getCs();
  nodeCS.setLimit(0);
}//end setCSLimitToZero


//convenience function created 6/15/2017
void
installConsumers(NodeContainer& nodes, int lowIndex, int highIndex)
{
  const int NUM_ATTACKERS = 6; 
  const int NUM_OF_CONTENTS = 10000;

  //ndn::AppHelper consumerHelper("ns3::ndn::ConsumerCbr");
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerZipfMandelbrot");
  ndn::AppHelper attackerHelper("ns3::ndn::ConsumerCbr");
  consumerHelper.SetAttribute("NumberOfContents", UintegerValue(NUM_OF_CONTENTS));
  //the value "s" is the alpha value in the zipf-like distribution
  //i.e., 1/i^alpha  
  consumerHelper.SetAttribute("s", StringValue("0.8"));

 
  consumerHelper.SetPrefix("/prefix");
  attackerHelper.SetPrefix("/prefix");

  //general attributes
  consumerHelper.SetAttribute("Frequency", StringValue("120"));
  //consumerHelper.SetAttribute("UpperBound", UintegerValue(5));

  //install regular nodes
  for(int i = lowIndex + NUM_ATTACKERS; i <= highIndex; i++) 
  {
    int freqVal = 30 + (i * 10 % 50); 
    consumerHelper.Install(nodes.Get(i)); 
  }//end for    

  //testing attacker at lowIndex
  //with really fast attacker (4 attackers)
  attackerHelper.SetAttribute("Frequency", StringValue("720"));


  attackerHelper.SetAttribute("IsAttacker", UintegerValue(2));  //yes it's an attacker
  for(int i = lowIndex; i <= lowIndex+NUM_ATTACKERS-1; i++) 
  {
    attackerHelper.Install(nodes.Get(i));
  }
}//end instalConsumers


//Added convenience function - 6/15/2017
//create actual connection from consumer nodes to the router
void
connectConsumers(PointToPointHelper& p2p, NodeContainer& nodes, int lowIndex, int highIndex)
{
  
  for(int i = lowIndex; i <= highIndex; i++)
  {
    //p2p.Install(nodes.Get(i), nodes.Get(i % 2 + 12));
    //p2p.Install(nodes.Get(i), nodes.Get(12));
    p2p.Install(nodes.Get(i), nodes.Get(1));  //direct to router
  }//end for  
  
}//end connectConsumers


//the handler for data recording
void
handler(ofstream* outfile, int iteration,nfd::Cs* cs, shared_ptr<PopMan> popMan ) 
{
  printContentStoreToFile(cs, popMan, outfile, iteration );
  //(*outfile)<<"Testing iteration "<<iteration<<std::endl;     
}//end handler

} // namespace ns3

int
main(int argc, char* argv[])
{
  return ns3::main(argc, argv);
}
